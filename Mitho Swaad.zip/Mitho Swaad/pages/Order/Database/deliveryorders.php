
<?php
     $Address = $_POST['Address'];
     $Orders = $_POST['Orders'];
     $Phone = $_POST['Phone'];
	$Name =$_POST['Name'];



	// Database connection
	$conn = new mysqli('localhost','root','','khana');
	if($conn->connect_error){
		echo "$conn->connect_error";
		die("Connection Failed : ". $conn->connect_error);
	} else {
		$stmt = $conn->prepare("insert into deliveryorders(Address, Orders, Phone, Name) 
	values(?,?,?,?)");
		$stmt->bind_param('ssss', $Address,$Orders,$Phone,$Name);
		$execval = $stmt->execute();
		echo $execval;
		echo "<script>
		alert('Check Availability sucessfull! Your Order will be delivered Sucessfully!');
		window.location.href='http://localhost/khanas/pages/Order/order.html';
		</script>";
		$stmt->close();
		$conn->close();
	}
?>
