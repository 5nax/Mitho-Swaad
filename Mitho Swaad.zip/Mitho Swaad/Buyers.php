<?php
     $Name = $_POST['name'];
     $Email = $_POST['email'];
  
     $Plans =$_POST['plans'];


	// Database connection
	$conn = new mysqli('localhost','root','','Khana');
	if($conn->connect_error){
		echo "$conn->connect_error";
		die("Connection Failed : ". $conn->connect_error);
	} else {
		$stmt = $conn->prepare("insert into buyers(Name, Email, Plans ) 
	values(?,?,?)");
		$stmt->bind_param('sss',$Name,$Email,$Plans);
		$execval = $stmt->execute();
		echo $execval;
		echo "<script>
		window.location.href='Buy.php';
		</script>";
		$stmt->close();
		$conn->close();
	
	}
?>
